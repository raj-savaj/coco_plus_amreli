<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use DB;
class ApiController extends Controller
{
    //
    public function register(Request $request)
    {
        $post=$request->all();
        $validator = \Validator::make($request->all(), [
            'email' => 'required|email',
            'name' => 'required|string|max:50',
            'password' => 'required',
            'phone' => 'required|max:10',
        ]);

        if ($validator->fails()) {
            return response()->json(["msg"=>"Invalid Input data"],401);
        }
        $mob=DB::table('user')->where('phone',$post['phone'])->get();
        if(count($mob))
        {
            return response()->json(["msg"=>"Phone no already registered"],401);
        }
        DB::table('user')->insert([
           'name'=>$post['name'],
           'email'=>$post['email'],
           'phone'=>$post['phone'],
           'password'=>$post['password'],
           ]);
        return response()->json(["msg"=>"Registration Successfull"],200);
    }
    public function userlogin(Request $request)
    {
        $post=$request->all();
        $login=DB::table('user')->where('email',$post['email'])->orWhere('phone',$post['email'])->where('password',$post['password'])->get();
        if(count($login)>0)
        {
            $login_data=[];
            $login_data["u_id"]=Crypt::encryptString($login[0]->u_id);
            $login_data["name"]=$login[0]->name;
            $login_data["phone"]=$login[0]->phone;
            $login_data["email"]=$login[0]->email;
            return response()->json($login_data,200);
        }
        else
        {
            return response()->json(["msg"=>"Invalid username or password"],401);
        }
    }
    public function getHotel()
    {
        $time = date('H:i:s');
        $restaurant=DB::table('hotel')
        ->where('hotel.status',1)
        ->get();

       /* $restaurant=DB::table('hotel')
        ->join('hotel_time','hotel.h_id','hotel_time.h_id')
        ->where('hotel_time.open_at','<',$time)
        ->where('hotel_time.close_at','>',$time)
        ->where('hotel.status',1)
        ->get();*/
        return response()->json($restaurant,200);
    }

    public function getCartData(Request $request){
        $post=$request->all();
        $hotelDetail=array();
        $restaurant=DB::table('hotel')
                ->where('h_id',$post['hotelId'])
                ->select('name','h_id','address','del_charge')
                ->get();
        if(count($restaurant)>0){
        	$hotelDetail["name"]=$restaurant[0]->name;
        	$hotelDetail["address"]=$restaurant[0]->address;
        	$hotelDetail["del_charge"]=$restaurant[0]->del_charge;
        	$cat=DB::table('hotel_menu')
                ->join('menu','hotel_menu.m_id','=','menu.m_id')
                ->whereIn('hotel_menu.hm_id',$post['menuId'])
                ->get();
            $hotelDetail["hotel_menu"]=$cat;
        }
        return response()->json($hotelDetail,200);
    }

    public function getHotelMenuApp($id)
    {
        $hotelDetail=array();

        $restaurant=DB::table('hotel')
                ->where('h_id',$id)
                ->select('name','h_id','address','cost','status')
                ->get();
        if(count($restaurant)>0){
        	$hotelDetail["name"]=$restaurant[0]->name;
        	$hotelDetail["address"]=$restaurant[0]->address;
        	$hotelDetail["cost"]=$restaurant[0]->cost;
        	$hotelDetail["status"]=$restaurant[0]->status;

        	$timing=DB::table('hotel_time')
                ->where('hotel_time.h_id',$id)
                ->select('open_at','close_at')
                ->get();
            $hotel_time="";
            for ($o=0; $o < count($timing); $o++)
            {
            	$hotel_time.= date("g A", strtotime($timing[$o]->open_at))." TO ". date("g A", strtotime($timing[$o]->close_at))." ,";
            }
            $hotelDetail["time"]=rtrim($hotel_time, ',');
            $hotelDetail["deliveryTime"]="20 MIN";

            $cat=DB::table('hotel_menu')
                ->join('menu','hotel_menu.m_id','=','menu.m_id')
                ->join('category','menu.c_id','category.c_id')
                ->where('hotel_menu.h_id',$id)
                ->select('category.name as category','category.c_id')
                ->groupBy('category.name')
                ->get();
            for ($o=0; $o < count($cat); $o++)
            {
            	$temp_menu=array();
            	$temp_menu["name"]=$cat[$o]->category;
                $arr=array();
            	$m_data=DB::table('hotel_menu')
        		        ->join('menu','hotel_menu.m_id','=','menu.m_id')
        		        ->where('hotel_menu.h_id',$id)
        		        ->where('menu.c_id',$cat[$o]->c_id)
        		        ->select('hotel_menu.hm_id','hotel_menu.image','hotel_menu.price','hotel_menu.sell_price','menu.name')
        		        ->get();
        		for ($md=0; $md < count($m_data); $md++)
            	{
            		$arr[$md]=$m_data[$md];
            	}
            	$temp_menu["menuData"]=$arr;
            	$hotelDetail["menu"][$o]=$temp_menu;
            }
        }
        return response()->json($hotelDetail,200);
    }


    public function getHomeCategory()
    {
        $category=DB::table('category')->get();
        return response()->json($category,200);
    }
    public function appSearch($query)
    {
        $result=DB::table('menu')
        ->  join('hotel_menu','menu.m_id','=','hotel_menu.m_id')
        ->join('category','menu.c_id','=','category.c_id')
        ->join('hotel','hotel_menu.h_id','=','hotel.h_id')
        ->where('menu.name','like','%'.$query.'%')
        ->orWhere('category.name','like','%'.$query.'%')
        ->orWhere('hotel.name','like','%'.$query.'%')
        ->select('hotel.h_id','menu.name as menu','category.name as category','hotel.name as hotel','hotel_menu.price')
        ->get();
        return response()->json($result,200);
    }
    public function saveUserAddress(Request $request)
    {
        $post=$request->all();
        $validator = \Validator::make($request->all(), [
            'u_id' => 'required',
            'name' => 'required',
            'phone' => 'required',
            'address' => 'required',
            'house_no' => 'required',
            'landmark' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(["msg"=>"Invalid Input data"],401);
        }
        DB::table('user_address')->insert([
           'u_id'=>Crypt::decryptString($post['u_id']),
           'phone'=>$post['phone'],
           'name'=>$post['name'],
           'address'=>$post['address'],
           'house_no'=>$post['house_no'],
           'landmark'=>$post['landmark']
           ]);
        return response()->json(["msg"=>"Address Saved Successfull"],200);
    }
    public function getUserAddress($id)
    {
        $user_addresses=DB::table('user_address')
        ->where('u_id','=',Crypt::decryptString($id))
        ->get();
        return response()->json($user_addresses);
    }
    public function placeOrder(Request $request)
    {
        $post=$request->all();
        $mrp_sell=array();
        foreach($post['hm_id'] as $key => $s)
        {
            $menu_price=DB::table('hotel_menu')->where('hm_id',$post['hm_id'][$key])->select('price','sell_price')->get();
            $mrp_sell['price'][$key]=$menu_price[0]->price;
            $mrp_sell['sell_price'][$key]=$menu_price[0]->sell_price;
        }
        try
        {
            $o_id=DB::table('order_master')->insertGetId([
                "u_id"=>Crypt::decryptString($post['u_id']),
                "a_id"=>$post['a_id'],
                "h_id"=>$post['h_id'],
                "total"=>$post['total'],
                "discount"=>$post['discount'],
                "del_charge"=>$post['del_charge'],
            ]);
            foreach($post['hm_id'] as $key => $s)
            {
                DB::table('order_detail')->insert([
                    "o_id"=>$o_id,
                    "hm_id"=>$post['hm_id'][$key],
                    "qty"=>$post['hm_id'][$key],
                    "price"=>$mrp_sell['price'][$key],
                    "sell_price"=>$mrp_sell['sell_price'][$key]
                ]);
            }
            return response()->json(["msg"=>"Order Placed Successfully"],200);
        }catch(Exception $e)
        {
            return response()->json(["msg"=>"Can't Place Order"],401);
        }
    }
    public function getUserOrder($u_id)
    {
        $order=DB::table('order_master')
        ->join('hotel','order_master.h_id','=','hotel.h_id')
        ->join('status_detail','order_master.status','=','status_detail.s_id')
        ->where('order_master.u_id',Crypt::decryptString($u_id))
        ->orderBy('order_master.date','DESC')
        ->select('hotel.name as hotel','order_master.o_id','order_master.a_id','order_master.total','order_master.discount','order_master.del_charge','status_detail.status_name','order_master.date')
        ->get();
        for ($o=0; $o < count($order); $o++)
        {
            $order_menu=DB::table('order_detail')
            ->join('hotel_menu','order_detail.hm_id','=','hotel_menu.hm_id')
            ->join('menu','hotel_menu.m_id','=','menu.m_id')
            ->where('order_detail.o_id',$order[$o]->o_id)
            ->select('menu.name as menu','order_detail.qty','order_detail.price')
            ->get();
            $menu[$o]['hotel']=$order[$o]->hotel;
            $menu[$o]['o_id']=$order[$o]->o_id;
            $menu[$o]['total']=$order[$o]->total;
            $menu[$o]['discount']=$order[$o]->discount;
            $menu[$o]['del_charge']=$order[$o]->del_charge;
            $menu[$o]['date']=$order[$o]->date;
            $menu[$o]['address']=DB::table('user_address')->where('a_id',$order[$o]->a_id)->select('name','phone','address','house_no','landmark')->get();
            for ($i=0; $i < count($order_menu); $i++)
            {
                $menu[$o]['menu'][$i]['name']=$order_menu[$i]->menu;
                $menu[$o]['menu'][$i]['qty']=$order_menu[$i]->qty;
                $menu[$o]['menu'][$i]['price']=$order_menu[$i]->price;
            }
        }
        return response()->json($menu);
    }
}
